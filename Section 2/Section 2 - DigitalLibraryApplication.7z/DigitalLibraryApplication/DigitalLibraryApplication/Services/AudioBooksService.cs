﻿using System.Collections.Generic;
using System.Linq;
using DigitalLibraryApplication.Models;

namespace DigitalLibraryApplication.Services
{
    public class AudioBooksService : IAudioBookService
    {
        private DigitalLibraryContext _context;

        public AudioBooksService(DigitalLibraryContext context)
        {
            _context = context;
        }

        public IEnumerable<AudioBook> GetAll()
        {
            return _context.AudioBooks.ToList();
        }
    }
}
