﻿using DigitalLibraryApplication.Models;
using System.Collections.Generic;

namespace DigitalLibraryApplication.Services
{
    public interface IAudioBookService
    {
        IEnumerable<AudioBook> GetAll();
    }
}
