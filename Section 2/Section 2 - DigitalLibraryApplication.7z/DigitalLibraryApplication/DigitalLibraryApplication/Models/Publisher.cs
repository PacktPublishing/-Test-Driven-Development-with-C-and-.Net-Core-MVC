﻿using System;

namespace DigitalLibraryApplication.Models
{
    public class Publisher
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
